---
layout: default
---

## About Us

### Contact:

**Lab PI**: *Paul A. Insel, M.D.*, Distinguished Professor of Pharmacology and Medicine at UC San Diego  
(858) 534-2295; pinsel(at)ucsd.edu

**Lead Contact for Data Access**: *Krishna Sriram Ph.D.*, Postdoctoral Scholar, Department of Pharmacology at UC San Diego  
(858) 534-2298; ksriram(at)ucsd.edu

**Contributing Author**: *Kevin Moyung*, Undergraduate Researcher, Department of Biology at UC San Diego  
kmoyung(at)ucsd.edu

**Contributing Author**: *Ross Corriden Ph.D.*, Project Scientist, Department of Pharmacology at UC San Diego  
(858) 534-2298; rcorriden(at)ucsd.edu


![](http://www.nature.com/scitable/content/ne0000/ne0000/ne0000/ne0000/14673543/U4.cp2.1_nature01307-f1.2.jpg)
(*nature.com*)

**Lab Website**: [Website](http://insellab.ucsd.edu/)


