---
layout: default
---

### This page provides expression of GPCRs in cell lines provided by CCLE (Barretina et al, 2012) and Genentech (Klijn et al, 2015)

GPCR expression is quantified in FPKM, as downloaded from the [EBI Atlas](https://www.ebi.ac.uk/gxa/home).

Data will be made available once our paper has completed the peer-review process.
